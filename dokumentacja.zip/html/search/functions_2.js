var searchData=
[
  ['setx_17',['setX',['../class_my_sin.html#a4b207c44bd5cefe56d643af283ffd609',1,'MySin::setX()'],['../mysin_8cpp.html#a07342ae260d070f339058cd3e54fd8e5',1,'setX():&#160;mysin.cpp']]]
];
