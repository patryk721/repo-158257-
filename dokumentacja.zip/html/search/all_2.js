var searchData=
[
  ['repo_2d158257_2d_5',['repo-158257-',['../md__r_e_a_d_m_e.html',1,'']]],
  ['readme_2emd_6',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]]
];
