var searchData=
[
  ['mx_15',['mX',['../class_my_sin.html#af08679a324cd4a438e5eeb3edbbaac24',1,'MySin::mX()'],['../mysin_8cpp.html#acb1c93f1767892c4eaf52e99114a5b63',1,'mX():&#160;mysin.cpp']]],
  ['mysin_16',['MySin',['../class_my_sin.html#a4faf6954cffe6838e6a43fe2cd125514',1,'MySin::MySin()'],['../class_my_sin.html#a44efe21f9bfc23fabe99f0205b60e3f9',1,'MySin::MySin(double x)'],['../class_my_sin.html#ac20007ba6d2cec60bd7d03f93a575dfb',1,'MySin::MySin(const MySin x)']]]
];
