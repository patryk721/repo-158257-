var searchData=
[
  ['value_8',['value',['../class_my_sin.html#a1a86f17bf0f1b3f8ab06b27ceb9daace',1,'MySin::value()'],['../mysin_8cpp.html#abbb27b323dda4135e516131e10ebcd3b',1,'value():&#160;mysin.cpp']]]
];
